import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { Link } from "react-router-dom";

const iiitv = () => ReactDOM.render(<React.StrictMode>
    <div>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
        <title>Profile</title>
        <div className="container mt-4">
            <center><h2 style={{}}>List of Students:- </h2></center>
            <ul className="list-group mt-4">

                <a href='#' style={{ hover: 'border-' }}><li className="list-group-item" style={{ border: '1px solid black' }}><span className="badge">1</span><button class="btn" type="button"><div className="row-4"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTvqFS9BwSimoDw7Z3UZmZFm7yN9SyhiQTqEA&usqp=CAU" alt='Student pic' className="img-fluid" style={{ height: '3rem', width: '4rem' }}></img><span className='ml-4'>Aayush Padariya</span></div></button></li></a>


                <a href='#' style={{ hover: 'border-' }}><li className="list-group-item" style={{ border: '1px solid black' }}><span className="badge">1</span><button class="btn" type="button"><div className="row-4"><img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5IddEo4v2q0IiSOwomPKuW9MZir6McjitNw&usqp=CAU" alt='Student pic' className="img-fluid" style={{ height: '3rem', width: '4rem' }}></img><span className='ml-4'>Kruti Joshi</span></div></button></li></a>

                <a href='#' style={{ hover: 'border-' }}><li className="list-group-item" style={{ border: '1px solid black' }}><span className="badge">1</span><button class="btn" type="button"><div className="row-4"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcST8F8--z5CdhblS5e6hH7DgsFPTlxs9p2w0w&usqp=CAU" alt='Student pic' className="img-fluid" style={{ height: '3rem', width: '4rem' }}></img><span className='ml-4'>Ritika Agrawal</span></div></button></li></a>

                <a href='#' style={{ hover: 'border-' }}><li className="list-group-item" style={{ border: '1px solid black' }}><span className="badge">1</span><button class="btn" type="button"><div className="row-4"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ81U2yy8Hni7VQr3YQzE9acmRwdHoM-pWs0A&usqp=CAU" alt='Student pic' className="img-fluid" style={{ height: '3rem', width: '4rem' }}></img><span className='ml-4'>Yash Jhaveri</span></div></button></li></a>

                <a href='#' style={{ hover: 'border-' }}><li className="list-group-item" style={{ border: '1px solid black' }}><span className="badge">1</span><button class="btn" type="button"><div className="row-4"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSyKyogWEYToOI_GLaMZ2omlHpjUgfuki9BvQ&usqp=CAU" alt='Student pic' className="img-fluid" style={{ height: '3rem', width: '4rem' }}></img><span className='ml-4'>Shaishav Trivedi</span></div></button></li></a>

            </ul>
        </div>
    </div>
</React.StrictMode >,
    document.getElementById('root')
);
reportWebVitals();