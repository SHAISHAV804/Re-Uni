import React from 'react';
import ReactDOM from 'react-dom';
import './profile page.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
ReactDOM.render(<React.StrictMode>
    <div>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
        <title>Profile</title>
        <div className="container">
            <div class="col">
                <div class="row-4">col-4</div>
                <div class="row-4">col-4</div>
                <div class="row-4">col-4</div>
            </div>
        </div>
    </div>

</React.StrictMode>,
    document.getElementById('root')
);
reportWebVitals();


