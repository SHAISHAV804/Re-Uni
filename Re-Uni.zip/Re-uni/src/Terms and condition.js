import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
ReactDOM.render(<React.StrictMode>
    <div style={{ margin: '20px' }}>
        <title>Terms and conditions</title>
        <link rel="stylesheet" href="http://themainlabel.com/assets/css/style.css" />
        <main className="header-offset content-wrapper about-wrapper">
            <div className="terms-container">
                <div className="row">
                    <div className="col-sm-8 col-sm-offset-2">
                        <section className="terms-title">
                            <center><h1>Terms &amp; Conditions</h1></center>
                            <hr />
                        </section>
                        <div className="terms-body">
                            <h4><strong>Welcome to The Main Label. Please review the following basic terms that govern your
                                use of, and purchase of, products from our site. Please note that your use of our site
                                constitutes your agreement to follow and be bound by those terms.</strong></h4>
                            <hr />
                            <h3>General</h3>
                            <p>
                                By using our website, you agree to the Terms of Use. We may change or update these terms so
                                please check this page regularly. We do not represent or warrant that the information on our
                                web site is accurate, complete, or current. This includes pricing and availability
                                information. We reserve the right to correct any errors or omissions, and to change or
                                update information at any time without giving prior notice.
                            </p>
                            <hr />
                            <h3> User ACCOUNT </h3>
                            <h4> Types of user accounts.</h4>
                            <ul>
                                In order to access and use the full functionality of Re-Uni, the users are required to create a user account. Before creating the Account, the user will be requested to read and accept these Terms and review the Privacy Policy. The personal data related to the Account will be processed in accordance with our Privacy Policy. The Account is not transferable, and the user is solely responsible for any activities occurring through the Account. There are the following types of Accounts available on Re-Uni:

                                <li>  Recruiter&apos;s Account, which allows the Organizations to create, upload, and manage the Records (e.g., students&apos; and class records, digital files, comments, messages, notices, events, and other content) and grant access to  to teachers, students, and parents. Recruiter&apos;s Account can be created directly on Re-Uni by submitting the requested personal data and completing the verification process;</li>

                                <li> Student	&apos;s Account, which allows Organizations students to access and consult their records. The credentials for accessing the Student&apos;s Account are provided by the Organization directly to the students;</li>
                            </ul>
                            <hr /> <h3>User&apos;s warranties.</h3>
                            <ul>
                                By registering the Account, the user acknowledges, agrees, and warrants that:

                                <li>The user will comply with these Terms and all applicable local, state, national and foreign laws, treaties, and regulations while using Re-Uni;</li>

                                <li>The user will provide only true, accurate, complete, and up-to-date information, including personal data;</li>

                                <li>The user will update the Account as soon as any changes to the personal data or other information occur;</li>

                                <li>The user can conclude legally binding contracts with us and is of a legal age to do so;</li>

                                <li>The user is not under any type of judicial interdiction;</li>

                                <li>The user is authorised by relevant parties (e.g., the Organization) to create the Account;</li>

                                <li>The user will register a single Account (multiple Accounts registered by the same person or entity are not allowed);</li>

                                <li>The registration of the Account does not create a direct conflict of interests between the user and the Company or Re-Uni; and</li>

                                <li>The user is a human individual and not a machine (machine-generated Accounts are not allowed).</li>
                            </ul>
                            <hr />
                            <h3>Security of the Account </h3>
                            <p>
                                The user is solely responsible for maintaining the confidentiality of the Account, including keeping secure login details and passwords. By using Classe365, the user agrees to immediately notify us about allegedly unauthorised use of the Account or any other security breach related to the Account. The user is also responsible for using secure Internet connection and protected networks while using Classe365. We cannot and will not be liable for any loss or damage resulting from user&apos;s failure to comply with these security obligations.
                            </p>
                            <hr />
                            <h3>Correction of Errors and Inaccuracies</h3>
                            <p>
                                The information on the site may contain typographical errors or inaccuracies and may not be
                                complete or current. The Main Label therefore reserves the right to correct any errors,
                                inaccuracies or omissions and to change or update information at any time with or without
                                prior notice (including after you have submitted your order). Please note that such errors,
                                inaccuracies or omissions may relate to product description, pricing, product availability,
                                or otherwise.
                            </p>
                            <hr />
                            <h3> FEES AND PAYMENTS</h3>
                            <p>The Fees. The use of Re-Uni by the Organizations is subject to the applicable service fees (the “Fees”). The Fees and payment terms related to the services provided through Re-Uni are made available on Re-Uni or communicated to the Organizations personally. The Fees are indicated in United States dollars (USD) and are charged on a subscription basis monthly or annually. By concluding a service contract with us, the Organization agrees to pay the Fees in accordance with these Terms and the terms and conditions in force at the moment the service contract is concluded. The Fees remain valid for as long as they are indicated on Re-Uni. The Fees are subject to a change without a prior notice.</p>
                            <hr />
                            <h3>The Fees exclude applicable taxes </h3>
                            <p>
                                The Organizations are responsible for paying all applicable income taxes, including on the income received under the Education Agreements (as defined in Section 4 of the Terms).
                            </p>
                            <hr />
                            <h3>Payment processing </h3>
                            <p>
                                All payments related to Re-Uni, including payments of the Fees, are processed by our third-party payment processors Stripe, PayPal, Fidelity Payment, GoCardless, and SSL Commerz (collectively, the “Payment Processors”). The Payment Processors are solely responsible for handling the payments. The Organization agrees not to hold us liable for payments that do not reach us because it has quoted incorrect payment information or the Payment Processors refused the payment for any other reason. Please note that the Payments Processors may collect some personal data, which will allow them to make the requested payments (e.g., credit card details). The Payment Processors handle all the steps in the payment process through their systems, including data collection and data processing. We do not have access to the payment data, unless such data is necessary for ensuring that the payment was successfully processed or maintaining our accountancy records. For example, we may store Organization&apos;s credit card details in our system in order to (i) ensure that all payments are processed in a timely manner and (ii) maintain our accountancy records.
                            </p>
                            <hr />
                            <h3>SECURITY OF THE ACCOUNT</h3>
                            <p>
                                The user is solely responsible for maintaining the confidentiality of the Account, including keeping secure login details and passwords. By using Re-Uni, the user agrees to immediately notify us about allegedly unauthorised use of the Account or any other security breach related to the Account. The user is also responsible for using secure Internet connection and protected networks while using Re-Uni. We cannot and will not be liable for any loss or damage resulting from user&apos;s failure to comply with these security obligations.

                            </p>
                            <hr />
                            <h3> ACCEPTABLE USE POLICY </h3>
                            <ol><li>When using Re-Uni, the user is required to follow our acceptable use policy outlined in this Section 7. We work closely with law enforcement and we report any inappropriate content that may infringe applicable laws.</li>
                                <li>The user is not permitted to use Re-Uni in any manner that substitutes or contributes to the following activities (the list is representative and not exhaustive):
                                </li>
                                <ul>
                                    <li>  Any unlawful activity, including violation of any laws, statutes, ordinances, or regulations;</li>

                                    <li> Fraud;</li>

                                    <li> Provision of false, inaccurate, or misleading information;</li>

                                    <li> Dissemination of information about the acts, including pranks and challenges, that may result in injuries and physical harm;</li>

                                    <li> Posting of the Records that depict or incite others to commit acts of violence;</li>

                                    <li> Provision of the Records that depict children or may cause emotional distress to children;</li>

                                    <li> Gambling, including contests, lotteries, games of chance, bidding fee auctions, sports forecasting or odds making, Internet gaming, fantasy sports leagues with cash prizes, and sweepstakes;</li>

                                    <li> Spreading of malware (e.g., viruses, worms, Trojan horses), spam, and other illegal messaging;</li>
                                    <li> Spreading ethnically, racially, or otherwise objectionable information;</li>

                                    <li> Spreading religious or cultural intolerance;</li>

                                    <li> Sexually explicit, libellous, harassing, defamatory, abusive, profane, vulgar, threatening, hateful, obscene behaviour and terrorism-related content;</li>

                                    <li> Advertising or encouraging the use of tobacco, alcohol, and any illegal substances;</li>

                                    <li> Copying, distributing, renting, reselling, modifying, compromising, damaging, disabling, impairing, and overburdening Classe365;</li>

                                    <li> Interfering with or abusing other users of Classe365;</li>

                                    <li> Using bots, scripts, and other automated methods; and</li>

                                    <li> Collecting and disclosing any information about other users of Classe365.</li>
                                </ul>
                                <li> Reporting inappropriate content. If the user has grounds to think that some of the content available on Classe365 is inappropriate, infringes these Terms, applicable laws, or user&apos;s or third party&apos;s right to privacy, the user is requested to contact us immediately at clientservice@Re-Uni.com. If any content is reported as inappropriate, we will immediately delete the content from Re-Uni and investigate the conduct of the reported user.</li></ol>
                            <hr />
                            <h3> SECURITY </h3>
                            <ol>
                                <li>We take appropriate security measures to protect the information we store on Classe365 against unauthorised access. The security measures taken by us include secured networks (we use SSL encryption), strong passwords, DDOS mitigation, limited access to personal data by our staff, and anonymisation of personal data (when possible). For more information on the security measures implemented by us, please refer to http://docs.Re-Uni.com/en/articles/457792-classe365-cloud-security-compliance.</li>

                                <li>Avoiding phishing and scam. Phishing is an online scam that aims to trick someone into giving up their personal data, such as credit card numbers, social security/national ID numbers, or other financial data. Usually, when scammers have that information, they will then use it to steal your money, property or identity.The user agrees not to disclose any financial information through Re-Uni or make any wire transfers to other users of Re-Uni or third parties outside Re-Uni with regard to Re-Uni, unless it is required:-<ol><li>to process user&apos;s payment or </li> <li>other legitimate purposes within the scope of the services provided through Re-Uni.</li></ol></li>

                                <li>The user is solely responsible for the interactions with other users of Re-Uni. The user acknowledges and agrees that we do not conduct any checks of the qualifications, certification, skills, and background of Re-Uni users. We make no representations or warranties as to the conduct of Re-Uni users.</li>

                                <li>Security incidents. Given the nature of communications and information processing technology and the Internet, we cannot be liable for any security incidents, cyber attacks, data breaches, and unlawful destruction, loss, use, copying, modification, leakage, and falsification of any information caused by circumstances that are beyond our reasonable control. In case a security incident occurs, we will inform relevant authorities without undue delay and immediately take reasonable measures to mitigate the incident, as required by the applicable law. Our liability for any security incidents will be limited to the highest extent permitted by the applicable law.
                                    <a href="email">customerservice@themainlabel.com</a>.</li>
                                {/* FOOTER */}
                            </ol>
                            <div className="container terms_footer">
                                <h3>Can't find what you're looking for? <a href="www.themainalabel.com">Email us</a></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main >
    </div >
</React.StrictMode >,
    document.getElementById('root')
);
reportWebVitals();