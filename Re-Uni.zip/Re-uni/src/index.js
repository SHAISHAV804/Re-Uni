import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

ReactDOM.render(<React.StrictMode>
  <div>
    <title>Contact Us</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossOrigin="anonymous" />
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css" />
    <section className="vh-100" style={{ backgroundColor: '#328ba8' }}>
      <div className="container h-100">
        <div className="row d-flex justify-content-center  align-items-center h-100">
          <div className="col-lg-12 col-xl-9">
            <div className="card text-black" style={{ borderRadius: '25px' }}>
              <div className="card-body p-md-4">
                <div className="row justify-content-center">
                  <div className="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">
                    <p className="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Login<hr style={{ height: '2px', background: 'black' }} /></p>
                    <form className="mx-1 mx-md-4">
                      <div className="d-flex flex-row align-items-center mb-4">
                        <div className="form-outline flex-fill mb-0">
                        </div>
                      </div>
                      <div className="d-flex flex-row align-items-center mb-4">
                        <div className="form-outline flex-fill mb-0">
                          <input type="email" id="form3Example3c" className="form-control" placeholder="Your Email" required />
                          <label className="form-label" htmlFor="form3Example3c" />
                        </div>
                      </div>
                      <div className="d-flex flex-row align-items-center">
                        <div className="form-outline flex-fill mb-0">
                          <input type="password" id="form3Example4c" className="form-control" placeholder="Password" required />
                          <label className="form-label" htmlFor="form3Example4c" />
                        </div>
                      </div>
                      <div className='d-flex flex-row-reverse mb-4'>
                        forget password?
                      </div>
                      <div className="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                        <button type="button" className="btn btn-primary btn-lg">Login</button>
                      </div>
                    </form>
                  </div>
                  <div className="col-md-10 col-lg-6 col-xl-6 d-flex align-items-center order-1 order-lg-2">
                    <img src="https://img.freepik.com/free-vector/online-registration-sign-up-with-man-sitting-near-smartphone_268404-95.jpg?w=2000" className="img-fluid" alt="login image" style={{ height: '25rem', width: '25rem' }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</React.StrictMode>,
  document.getElementById('root')
);
reportWebVitals();