import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

import {
    BrowserRouter as Router,
    Switch,
    Route,
    Redirect,
} from "react-router-dom";
import Home from "./src/rec-index";
import Nirma from "./src/Nirma-students";
import iiitv from "./src/iiitv-students";

function App() {
    return (
        <>
            <Router>
                <Switch>
                    <Route exact path="/" component={rec - index} />
                    <Route path="/Nirma-students" component={Nirma - students} />
                    <Route path="/iitv-students" component={iiitv - students} />
                    <Redirect to="/" />
                </Switch>
            </Router>
        </>
    );
}

export default App;
ReactDOM.render(<html>
    <div>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
        <title>Profile</title>
        <div className="container mt-4">
            <center><h2 style={{}}>List of colleges:- </h2></center>
            <ul className="list-group mt-4">
                <a href='#' style={{ hover: 'border-' }}><li className="list-group-item" style={{ border: '1px solid black' }}><span className="badge">1</span><button class="btn" type="button"><div className="row-4"><img src="https://www.msubaroda.ac.in/asset/images/MSU%20Logo1_pp.png" alt='MSU logo' className="img-fluid" style={{ height: '3rem', width: '3rem' }}></img> The Maharaja Sayajirao University of Baroda</div></button></li></a>




                <a href='#'><li className="list-group-item" style={{ border: '0px solid black' }}><span className="badge">2</span><button className="btn" type="button"><div className="row-4"><img src="https://spng.subpng.com/20180609/rvf/kisspng-institute-of-technology-nirma-university-faculty-5b1c69a3bc0089.5029184915285887077701.jpg" alt='Nirma university logo' style={{ height: '3rem', width: '3rem' }}></img> Nirma University</div>
                </button></li></a>



                <a href='#'><li class="list-group-item" style={{ border: '1px solid black' }}><span class="badge">3</span><button class="btn" type="button"><div class="row-4"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAL4AAAEKCAMAAACbhh94AAAAkFBMVEW9Fx7///+8EhrHREm5AAC7AArFQETYh4m8DRbJTFC7AAC7AA+9FBu8DBW3AADBMTbou7z88/O7AAbw1NXrxcbZj5H03t/35+fem53++vrSdHfuzc7iq63pv8DEPUHLWVzOZGf57e2/HSTQbXDfn6HBKS/HUVTSfH7clZfhpqj14eLVf4HAJy3OZWjTd3rLXF/VliRfAAAXRUlEQVR4nO2di5KyuBKABZsRQ/CCiqKMDur4q+OM7/92h1wBJZCgHGur7Nqq3R25fIROp9PpDp2u3fnPit3tvPFfJm/8V8ob/5Xyxn+lvPFfKW/8V8ob/5Xyxn+lvPFfKW/8V8ob/5Xyxn+lvPFfKW/8V8ob/5Xyxn+lvPFfKW/8SnGR1+LVW8b3YD1aItTeDVrExwH6WlmWlRw74LZzi/bwMfJ6c4vL6AP8Nm7SFr4NnUVEwOe945j8e3WANjpBK/gufMe01acbcBD6oW9h8tXCA7SA78Lwk6nMkKmMA8uQ/H/4+/QHeDq+LeBPl6zDevArHuC5feDJ+BhdRgx+WzSX8gGuT7VCz8UPvD2Fj7f3tt6D3Zl24g943g2fie/DP2plpsNyQA/+JbRPbBF+0i2fh4+hz9Rjo1YPBx2pOV08y5V4Gr7jUVuZLCs7J0Zbeth88xwNehK+DTuqN3Hg1B55oMPAyA4ev+2T8IPtlDb9FTSU2ke0f4//nvACnoGP4R/V6NjT02gMH7SXrLZ1r6pWnoDvO2ycWuo0PT8F6AuIfuGxWz8BH/WpNTwPkclZ8Etf2Ak9Nog9io+hxwYqUw7nMqGO3OUhBXoQ33Von7V+9BVHngrUhI6/HlGgx/C9LfUDrKuR4gjhL673AP9D+M6aGvvxR0MTDjvKvzd/dUIewUcHNqG6NPYA0IZNDBr7QA/goy967/n2ARceHeg1Vk35m+Nz+uQR+of5G+MHV3rf8fDB6RP6fYS/Kb73wUIg3Yc9X5gx/W9kfxriu1tqc6xdI4tZFGBDx6IJfzN8jEJu8hrc8u5iDgtnLRs0RTN8NmBa4RPaPhW/yxRxaO7/NMJ3lux+6ycFDdCxaWs0wbc7TPFnWrcLLrWHYMTU52jM3wQfWChnrmXrIP6tN63eV0P1aYDvsZHe2unYTDhaV42RASbM+puaggb43OpMdG7lpE7lj8Zjiub/MhxGzPG9pcGdUKpn/7QOZJ732VD7zfEhNLgRijXxnR/WKDqalhNjfL/P7tPTmuRptz7uUOfbmpppvzE+YiNWtNU6C1a6DwosXGHpXVeIOX6i33FN8L1fk7cqxBRf6M5Rb36oj49tpj2hkfaY4rMAn2V96A0wxJ5rtic3CdHFBMcUn48vY00DRw7X9IR5pzKzPYb42BkbDY8UX+9RnZ6RWjIxxHfX7B6xbuuH2vg+90VGJiOXIb7PB/e9Lv5ZG98eWiY2jZ9khi88Bl3zRvA13xS2mV4mLeILBV1qulYEX1cb+IiStKg8wcLAWU4Fxvr9hOPrGjUqhvjC7LeJ36Ll8X4MdT/Fn2rqvtu+7vtXQ8OpP0YIm9ym5RH30PVrDfC9Xft239Q8GOALp8HI5TT2ebhbPtQ7yQSfp44ZBY9M8b0/dpM/LdODPW1ldnnM12y2a4pvb02U3wBf6I6uO8JxTGdbQnu03HJ9fOxGRlrJpfFUXcsRsy+W5vwJsSi/9dnyVF1MWKKOxmnUizxrEIkxyzTqa44vwtmxBpU2Po+4G6+xNAgSAvd71vWzOjrKaeCLsOlY55XmpQE+lgG92ggznUHNa/HFUpP1Z7q+3SRA7q91uxnFH9cdZvOgr2m/7TRcXUF8zlUbQ9DCx2jFR6zAeHG04drWkfsnNWR0blmDbwv6Of4/rW1l3XdRnU3h/SMmthLfDybN6RsvS4v2n6Iq+8M8pEHFEegj4ZrThL55UgDwede8r04I9OFEDkFKe+LxJfXULXUarVI+kJKx4dbu81L+AD4cmIWN/kGpD+/D9WxpKaFSHkiI8TD33qz4At7N7d0ADlNLyPwf3Oa6pQdcudZb403T1flqfNv3HAchBFIQChzP8+kpNlxFdcp05wHyXIzZSQiGR1m4wgj3a0COTx8Su+kB65k8IHY8/mcH8vfiN3T47UzxAQ03y95scfqcShmdZr2/3eZCLuy5qe5GAmKyWPa3Qfrn4fVvxPujleSeYD76OfgpXdDp/ouzh5uugTwvQKe/+1mMptPJJEzmqSThZJLecN9bboaOQrcq8L38ve8knO6XawQDNFMfNv6iPRNNlUek8ANA/b94elYfQ650q5y1+GJeVSmT+O97sPmMyn5LeghoUA5gPSo9e77w0W88Kf3tRhRLXmp8N52XRJPJZ3w6LhaL4yn+nITnccmVo2lvuImLqm7N42tqbhDF97ELXm91++Szy2Yflj32OVzF+8VxRmWxOI3S1umX21U1PhkxJ+mbTTsrEdqBEfKHX7PTKrm95fm4RddFvJqEYTgZLf62iA5nDJ+8eOwA9NMzQ3LA9NT7GHTj23cWhZ+L3dBhNwoCh0oAaJC+n5/y8Ikan4Qz70NG2PYdBKjztZ/c3H1yHVBDkf4KHr8kw+f9DpMz6QEwgJ+bt3WOf77TEwPPvldykm6lmMFX4Kf6OlONlzi1Fah7LCpE+HVbOcHCB7ez77y9IjL+/JdaOU9pHQmJIvamxgf1K+OSjjzOrtBtJ/3i+FOGb8NXXvfOiz5CCrsirrJXhisqWv+sEQfH6Wi1zNvFU6HupgTf6+QPH/XvhuN7IfkOiuiVGt9J2+hXI5aWPgFeZBbpnM9oZ/jdHCBssreVzBytIjoSvE0Muy6NG33prbFixCuyqORKIhj+JruK9DBTdfgFzdkVSfaJSrp0Jf62eOMacaAn38BM8rPxNrsKyOHrfNUvv6TLmVszfBqi6Ro44QFaCLaj4AdqmuQ6uaSPeia1oxT/u5xShe92DfFTFfoW47+YAzN8kdAjYlHWyDcKiFD88vCbEp8GCYzwST2HUO1dcI+P+KJq9Gs4N6H45Xqsxv8yx095+dqX9U3PzOOL4GLybRqLaoJPZ9kH4wlosM6n5TB8utyDxbKSa5wxT9MMy4cgNT4J0WgazsJ5PARHU2xZNJric8WPLg0uSRbtytfxn44v6gno+kWGL9Z+1g3y/WmWYflqVDW+7uJ5QXgIi8S6M3yepN8kyb3jzBroPsG/ddmwXvogc4ZTV4fhL5BYD9ZbEbudmdNMhCZdd1E0Eni9hsqoGr89szEx4vlpKT6iA1bk11vM1BP/7ReJ6Mnl0y214SQm8NbLDlbJqV/fgmx0jYDmwzB8NhrXqw7sRnd3RZ/mwxYddW9XlDGxhPUVHzamtAef4ceILfhHtesZmNinu1UnqoKm+ERb72LbmFxqVDtqsuY/IYFP2y/9/5rTbOLi3S9vQWKpFmLVLhuNk7i3oBhNSJFVTRdmaXUhCHzWmetWDf0gLKPHARkJO4Ye58UqHXbpSk7o1XRgoGMvou2WEnl0vK0KlKfifSfENt1hUjVWxKmqpytlg4XtzYnjUj0iMDPfH7DNbYBW9n1W6w50I3LoPSXtOHPjSMNcoa4uqbOKupUwAXU9exx/QH3N6nk/EMcmLOvc1Owbz3Wp3pYms7hbohOVVc4sYXIm8OnDVHogdLUjLO1T9E0aRxroWeXLaj5dh/2p4PcPOfwJw6/yvmkwdF4e6iH5cKrsswrlKQ0xcboh6RgV66IsJXY2sHL46lwRTA3t3Cs37fRSiszmikAJvaci39Sj/LFyAGA+jia+S5dGk07526GrkyrNU+Oz969KGfRoXsxUNQCwjMM/gf9Xpfu+S3qZsmyZuUuKZ1fj00iJOhnHofyqASCg66bfDP8M9FKKgKkzJIYg+lZ1bDp2KMI8VasrLDdOmTXFyqUVAwB1UyIQ+LT3lafkoT5Rw2ioGkfooKXMcKvAz01USwVR/qhb0qjYpUoDSODTS5UZdWBzM/UkjL1HVZ5PVevvLWWbsQNY4mjJHhPs1Bn49IAxsNzhEn+Z7zTRV49obMajKqmoWppjeSPlvhK7NOP/u/NLEXV5HNvj+Mzfv3OYMZ9XHtShE+Z6KaOVFfi8nKGq6I1nBhxv+FlUIfWrM3z6l2nRabN50LBqixBeMKAqRqta12WRmcokWLE/TGEA4A/1bXN8Czr8vwrP6SIWU/yq8p6Y7ihzUyuXpVl0oDKzkmeW5AYADEzpZihVO4HfcVj2bS53wcdsKbdyswGXaYAyYb0Kn1dxVk+S2NKtFQZ8zHR4Oix5aaKahrQ5T1/9DHgH4NuzWMvKqSc6sRekGhSq8HnjRdUrTyzpxUrIRivYgT9GRfP0BD5Vef4uoyNdM+Wbe9TkY2EcVRNUpmQwc61eX+RHseYefwD4Pb62P3HIRQU+vTsW0f1xfEDcZtVlk/EtBNQpepX4vCIgqYkQCK69XN7nKl7AzzKY0ieYiOMqLyzCugflTKE6IYaf3qsJaUMxZWEldtkSgU3x7tG2eGBdJiJv/Iqc+Bp8ttyQqPJRJH+22BmNDnJtVFS6SL/Jhu0ikYfWpRGLrPI/9ZhcjS8uUJcujnkvsaID5NY6RRlizvTaaNDlS6O1+cr8pVYVmtQkg/HXF11qQjQiq986b3ODdAk+94918EVic0Xj1+FjYHawZvsQ7uTQXpkLQUj87OGFwbRqDbLot5XVIHWpeA63cLduTVFYKIZjZcvSor40t7D7T7wlqzZywtch+1UBitpMQtErK5P9aCA8EPklclna+1fExyCWfkfEBa1MLRdWtjogXItv8zpUq69+ibTKfwWi/0oP7gbflj0kBtoqPfUlgVco1WhtfR6nJ7RV6RkyLb36WObcrViaiMBn4QrfDyU9s6nqAhK5QFyzZ4xGGioSg+WfIi5CG5X0MJwZoI6Xw6dThszkUHtP9W1SfkWX+1HpeFtTQqeTRSs1Ni7NRGA/Xz35JETG66CIn5kcps0sDjMqyx9GQ+F9/NauCOgkAUv+5H4bbp5mLRbdJD+JgYra6hRf6HLWF5llmd5uXosdkTyQvu7axSS9HObs5pMNBLnjXfigLZXVzMi8i9SbFPi9QDZA5ufw3cXGu1z+M/YRWgoDPD7UL4VppmCjrlBc69zbIuT4vu85CHW5D/aRyziS/PFA4A+kq5bzkN0Ou2a4dAEF5GrgbGKZFTTpaCwq62aQ+07OWTyPZl+bzW9P5J5GhUBHxj8VtdXSky74977szOFptpztT6tclute65MP2gnwGDZlKa/05jc7Wkq7Yd0mmt7E1H1XlQC8WuulxBvk7/t8E/dbWdzlAorKllu5m9fa0CtLf572dbeJNyo/8OAwurldFF9KOlg5f9msHPzZTT5tchrqb9JvWmoP6LpfiUdIRn92uYpmliaT8k2XcQDXVOnZlPz82dNJ7GyMT54AAVp/7XZfhy2o019zGY9c1NEoUpPgX9bDS/pvwwqcZrUrru95/t2SdUFu+StjaSRXxbUb1NA8b//9WynyawxBTaQ9/NxQXRlDfkhaxO8McnGflm7RJj688Wvkja+UN36dvPGV8savkze+UjJ88w2WNaVFfJyVnJrukKstbeIPNwcu12d9oOpW2lQe7Et53kXtwjRDnUHuPCr58AN+0uUc9NHPb0ygwvd2vQdl1sv2TsfD2ezR65EwNfTmq8/JKvtghAofboubjWWVT3z0D1ol3VUSQgfi1RY5g2sis6Hbwp/chGpcdZRL94rgX8PB6jxJdmuZYdcO/nx3H6rxYTevP7MKHyabwfk42CeD6cZtD3/8U/4lPA/1ykr19fHnPoSr2XwEvYXTFn50DNi8HHtysBJB9cBblO6JYIA/Wp0HTnv4pw5L4HCR80+s+qP4uGXaJL701wx/chicFxfr2pryjL7ZapUH69NYpn2TZcTRAWhmhPwGqTk+6bqj3iCO1+dWui7//qaN0I6evsrhk3UNl1ojF/pNrGjaFrBfeQM02CTDFgwn/7ylD98ia6SIT8LRXboS5MPV3IqSVwl/5+nnZHp5/rDFbKUdoGuWHHOLTyD+HBJB9tAyaYCfnrfubzWcBkP8hNpKH7aFaH0JfmpWT2uyPOmYWlHekfRcNiP86OgEJA1vc9MpS/HJ33cI2Ri5ikWYSvyiPAM/Tm2lD53e3RY7Kvz0bS2+wbfRxcCKtoQ/GoLrQP921agaP5XpFQU+rCu2HnoEX9O2rVJbAv5PuSGpxE97+2wLDuj6oi3gp7YSwf1GO5r4LG8PwW/1xk5t4ae2Epy/igNr8VMJf3zIbxHy/8If92BAPIMK0cEng9nHAM1qXbmn4o+PALu6R9TDJ2hLQPuaB3gq/rmzrx91tPHJtnPbmslMK5bnWfj1Yob/4My0cMfH5/2WooJMhe9+9B+XD35lPFyXyMeNdO+lcLGy9XZ1rfoTJCsIecbVyihbxX+umODj21f7eikL8yrwsd84ItCWlBbbq/C9ByIy7YgRvv9q2jsxwU9tXSq4fBtNK96SX4fbjRwo5+lf+OZNx8tQyoWPV2N3WCJ8nP2kV9sq3M6fCy94McLv2LYNIp11dDqd8rt+xmCTn3+yvyTI9XmZ0AzZUlwxeB+89P/QICdgu/xjGSNyNZl9m97qNMqNmcsAmuDLgrv0+oMB2YYyK/uhNXiIpeuMhusV2apMVjnN8jmd4jstZD/KYG9FUsg2MAIfZd+MtX7oDqCwlo219FAzfOmpRPP9NiDxMTEzJfgcbAWuv01nTZ07fHZV7nwQ78c5Jmduz+bzJM7j40BYinHYI0V1PhL8TfHdbvYGrYjU5IrvyFJ8vuk8WSjAhRI5hu8DKz5nxc6sUMID9shJN21gp5PDd3q5eyXke9Xu94P4qBgFWKbtH/QkPi+oy33ZII/vwXXFPgbIj2PbqItdn3j4PMNHxX5L2kR0hqb4TtHyk89aiio4sm3TRL6He3xvx2oLsndI8Xn5taw2k/jiukImKPs+TUN80ems8YxN5I5BB28jDi3+K1eIn+GLr1r9OrL2iSoPf2S5MCXxHZF0GP6wV77xZdFUQ3ypjgdg5Z2pv43xmOOLi+f2GxV/Sluf99ex44i6NVKdgB36n9n3tCQ+ErWkPhrE/KX6h4fwxXfNyCwBEerIxhm++LpU7puO4nlTfKEMyRfwt0Q+EcyBsuJxst8qxRejQyx2QEtv+ih+LC/JTejazeEL/chaX9hZ0nVlCjzvP3SPAP58cm82sc32iO/9xK5Gmyp5vPVHGQ17lIOfw+fDTLaNgKhLpydgVOz3tGKWf2ZP4otvuqbKw/FJXS7dFmjs4ye1PumcrGI8j+/zW2e7O8u9UKndF9+K5m+QmU12hLS1oso3a32ydRxVpCfgi49jBNmGvhm+yz+cJKf/7kWwsmErF1xIeMUHH8HEbmPyjEz3N6L1H1ceUS45ErofbXNdV05n+CqTnUUmGL7cP/66Rdy4yr5N35gs8SXKcxKoXPfPD3ddUWmcWmzmkczzhlPGPlZkSchFThYK4T6P+ALVfCDuKkeSIfJ9FMiljJE0wyPg38N63HDKvrsD5jinl+T7DlCnQbiIkw9AH8dcTxUuG3BHICv5FP05mh0OuY2nc07DBQ2o0u28jpvhfzbBl411ZK+WDJZ84wnqst3F9P4dC/jiu2JW18Gpi9bJ9W4u06vAF58lT3oUNSH7Szsxx7eH8wb4svMyYdYD0T24Cb53tYryBWx3D+nvC+M/XkM8HblZ/TOXCUIfY4v3rkJMcsl6/w/D77hUU03xpfrQe/HaTud7LqYreSfXCsnW46g7zk9X8qFNau3ZhmJcRulQ5uOQ4ds49zJFETttK9KdMWkJY3yc1W+c5E4TrjPlfib6kjDRjGXveJ0wP9vK6of4dne+3P59vKTtYSO+/abrybbK6spJW7FaX/hnjk/2hTiuwnB13OYSGTHEfL9Pz5/RLnc+ytwRF6aL3GQRDUfUB5iJulwb1vtJGI52wppiWHxyQ7o+pb9M9t+5e7lo8sP3oD4kZaU+NZmEdkA+5BIUj0BDfiEcIP97iFFuJ3csf+T3R5fhJf/RIZd83CGf7wPiBPJL+k/hXjgQv3qXbRlfk0TIHCC2b7ccu22juwMqrlb1q9mGlv8NeeO/Ut74r5Q3/ivljf9KeeO/Ut74r5Q3/ivljf9KeeO/Uv7z+P8DlQCWxsOkXBIAAAAASUVORK5CYII=" alt='Navrachana university logo' style={{ height: '3rem', width: '3rem' }}></img> Navrachana university  </div></button></li>
                </a>


                <a href='#'><li className="list-group-item" style={{ border: '0px solid black' }}><span className="badge">4</span><button className="btn" type="button"><div class="row-4"><img src="https://studentcorner.epsiindia.org/upload/college/Parul_university.jpg" alt='Parul logo' class="img-fluid" style={{ height: '3rem', width: '3rem' }}></img> Parul university</div></button></li></a>





                <a href='#'><li className="list-group-item" style={{ border: '1px solid black' }}><span className="badge">5</span><button className="btn" type="button"><div class="row-4"><img src="https://images.shiksha.com/mediadata/images/1577942214phpYQ6tGZ.jpg" alt='pdpu logo' className="img-fluid" style={{ height: '3rem', width: '3rem' }}></img> Pandit Deendayal Petroleum University</div></button></li></a>



                <a href='#'><li className="list-group-item" style={{ border: '0px solid black' }}><span className="badge">6</span><button className="btn" type="button"><div class="row-4"><img src="https://yt3.ggpht.com/ytc/AKedOLQ0VvvuLk4YfO1AmhjgDKloISlfQbqcu5NfL5EH=s900-c-k-c0x00ffffff-no-rj" alt='Depstar logo' class="img-fluid" style={{ height: '3rem', width: '3rem' }}></img>DEPSTAR University</div></button></li></a>


                <a href='#'><li className="list-group-item" style={{ border: '1px solid black' }}><span class="badge">7</span><button className="btn" type="button"><div class="row-4"><img src="https://upload.wikimedia.org/wikipedia/en/thumb/4/45/Indian_Institute_of_Information_Technology_Vadodara_Logo.svg/640px-Indian_Institute_of_Information_Technology_Vadodara_Logo.svg.png" alt='iiitv logo' class="img-fluid" style={{ height: '3rem', width: '3rem' }}></img> IIIT Vadodara</div></button></li></a>



                <a href='#'><li className="list-group-item" style={{ border: '0px solid black' }}><span className="badge">8</span><button class="btn" type="button"><div class="row-4"><img src="https://www.gsfcuni.edu.in/public/logo/01-logo.png" alt='GSFC logo' className="img-fluid" style={{ height: '3rem', width: '3rem' }}></img>GSFC University</div></button></li></a>
            </ul>

        </div >
    </div >
</html>,
    document.getElementById('root')
);
reportWebVitals();


